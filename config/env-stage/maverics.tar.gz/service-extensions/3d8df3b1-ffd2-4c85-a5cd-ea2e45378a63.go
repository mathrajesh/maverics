package main

import (
	"fmt"
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

func CreateHeader(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) (http.Header, error) {
	logger := api.Logger()
	logger.Debug("se", "building custom header")
	
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return nil, err
	}

	firstname, err := session.GetString("okta.firstname")
	if err != nil {
        return nil, fmt.Errorf("unable to retrieve attribute 'okta.firstname': %w", err)
	}
	surname, err := session.GetString("okta.lastname")
	if err != nil {
		return nil, fmt.Errorf("unable to retrieve attribute 'okta.firstname': %w", err)
	}
	preferredName := fmt.Sprintf("%s 'The Great' %s", firstname, surname)
	
	return http.Header{"preferredName": []string{preferredName}}, nil
}